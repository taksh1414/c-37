# Contributing

1. Fork it!
2. Checkout the master branch
3. Create your feature branch
4. Add your changes to the index
5. Commit your changes
6. Push to the branch
7. Submit a pull request against the master branch
