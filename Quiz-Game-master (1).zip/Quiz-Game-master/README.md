# Quiz Game 

# Quiz Game developed in C.
This program will maintain a list of random questions & options. According to the answer given by the user it will check with the true answers. After checking true answers, it will display the result by true or false with grades. If false then there is negative marking in the game & if true then the grades/score will be incremented. At the end result will be displayed with final score.  

Download from here: https://github.com/nishittated/Quiz-Game
 
# Future Development
* Timer in Quiz
* For All Questions only 1 File
* Display write & wrong answers of every questions at the end.
* Advanced algorithms & better interface.
* Save per users details along with his final score in a file. 

# Developed By: Nishit Tated & Ankit Shah

# Find this project useful? ❤️
* Support it by clicking the ⭐️ button on the upper right of this page. ✌️

# Support or Contact - Let's become friend
* <a href="https://www.instagram.com/nishit.tated/">Instagram</a>
* <a href="https://www.github.com/nishittated/">Github</a>
* <a href="https://www.facebook.com/nishit.tated/">Facebook</a>

# Contributing to Quiz-Game
* All pull requests are welcome, make sure to follow the <a href="https://github.com/nishittated/Quiz-Game/blob/master/CONTRIBUTING.md">contribution guidelines </a>when you submit pull request.
